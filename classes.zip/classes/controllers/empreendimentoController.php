<?php

	namespace controllers;

	class empreendimentoController
	{
          public function index($par){
          	echo $par[1];
          	\views\mainView::setParam(['nome_empreendimento'=>'Empreendimento de teste','imoveis'=>\models\empreendimentoModel::pegaImoveis(0)]);
          	\views\mainView::render('empreendimentos.php');
          }
	}
?>